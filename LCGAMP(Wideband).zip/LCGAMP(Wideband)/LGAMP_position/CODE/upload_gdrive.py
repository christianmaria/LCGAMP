from google.colab import drive
drive.mount('gdrive' , force_remount=True)
!mkdir -p 'gdrive/My Drive/colab/lamp'
!cp LAMP_bg_giid.npz 'gdrive/My Drive/colab/lamp'
