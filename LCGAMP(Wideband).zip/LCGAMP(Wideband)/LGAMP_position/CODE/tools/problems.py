#!/usr/bin/python
from __future__ import division
from __future__ import print_function
import numpy as np
import numpy.linalg as la
import math
import tensorflow as tf
import random
class Generator(object):
    def __init__(self,A,**kwargs):
        self.A = A
        M,N = A.shape
        vars(self).update(kwargs)
        self.x_ = tf.placeholder( tf.float32,(N,None),name='x' )
        # self.h_ = tf.placeholder( tf.float32,(N,None),name='h' )
        self.y_ = tf.placeholder( tf.float32,(M,None),name='y' )

class TFGenerator(Generator):
    def __init__(self,**kwargs):
        Generator.__init__(self,**kwargs)
    def __call__(self,sess):
        # 'generates y,x pair for training'
        return sess.run( ( self.ygen_,self.xgen_ ) )
        # 'generates y,h pair for training'
        # return sess.run((self.ygen_, self.hgen_))
class NumpyGenerator(Generator):
    def __init__(self,**kwargs):
        Generator.__init__(self,**kwargs)
    def __call__(self,sess):
        'generates y,x pair for training'
        return self.p.genYX(self.nbatches,self.nsubprocs)

def one_bit_CS_with_BG_prior(M=1024,N=360,L=1000, pnz=.025, kappa=None, SNR=40, tf_floattype = tf.float32):
    # This function returns an object called prob which contains:
    # the measurement matrix, both numpy array A and TensorFlow constant A_,
    # Tensors xgen, ygen_ which can be used in TensorFlow to generate new training data,
    # numpy arrays xval and yval which are used to evaluate the learned network
    # numpy arrays xinit and yinit, which I am not sure are used at all ???
    # and a scalar noise_va
    # f_c = 1e9  # frequency of operation
    fc1 = 2e3 # 入射信号频率
    fc2 = 3e3
    fc3 = 5e3
    w_lambda = 3e8 / fc3  # wavelength
    d = 0.5 * w_lambda  # uniform spacing of half wavelength
    # array_length = (M - 1) * d
    # B1 = 341
    # B2 = 343
    B1 = 101
    B2 = 119
    b1 = np.array(B1 * np.linspace(0, B2 - 1, B2))
    b2 = np.array(B2 * np.linspace(1, 2 * B1 - 1, 2 * B1 - 1))
    position_x_u = np.sort(np.append(b1, b2))*d
    # position_x_u = np.linspace(-array_length / 2, array_length / 2, M)
    position_x_u = position_x_u.reshape(M, 1)  # uniform positions for ULA

    def generate_random_signals(lower_bound, upper_bound, size, scale=None):
        sample_space = (lower_bound + upper_bound) / 2
        if scale is None:
            scale = (upper_bound - lower_bound) / 2
        results = []
        while len(results) < size:
            samples = np.random.normal(loc=sample_space, scale=scale, size=size - len(results))
            results += [sample for sample in samples if lower_bound <= sample <= upper_bound]
        return np.array(results)


    az_theta_D = generate_random_signals(-90, 90, N)
    az_theta = az_theta_D * math.pi / 180  # DOA to estimate
    phi = np.array(2 * math.pi * np.sin(az_theta) / w_lambda)
    phi = phi.reshape(N, 1)
    A1 = np.exp(1j * fc1 * np.dot(position_x_u, phi.T))
    A2 = np.exp(1j * fc2 * np.dot(position_x_u, phi.T))
    A3 = np.exp(1j * fc3 * np.dot(position_x_u, phi.T))
    A1R = np.real(A1)
    A1I = np.imag(A1)
    A2R = np.real(A2)
    A2I = np.imag(A2)
    A3R = np.real(A3)
    A3I = np.imag(A3)
    A = np.vstack((np.hstack((A1R, -A1I)), np.hstack((A1I, A1R)),np.hstack((A2R, -A2I)), np.hstack((A2I, A2R)),np.hstack((A3R, -A3I)), np.hstack((A3I, A3R))))
    A_ = tf.constant(A, name='A', dtype=tf_floattype)
    prob = TFGenerator(A=A, tf_floattype=tf_floattype, A_=A_,pnz=pnz,kappa=kappa,SNR=SNR)
    prob.name = '1bit CS, BG prior, Gaussian A'
    prob.pnz = pnz
    # prob.code_symbol = np.sqrt(prob.pnz*N/M)
    K = 3
    prob.code_symbol = np.sqrt(K / M)
    bernoulli_ = np.zeros((N, L))

    for i in range(0, L):
        random_list = list(range(1, N))
        index = random.sample(random_list, K)
        index = np.sort(np.array(index))
        bernoulli_[index, i] = 1
    bernoulli_ = (bernoulli_).astype(np.complex)
    xgenn_ = bernoulli_ * np.exp(1j*np.random.normal(0, 1, (N, L)))
    xgen_r = (10*np.real(xgenn_)).astype(np.float32)
    xgen_i = (10*np.imag(xgenn_)).astype(np.float32)
    xgen_ = np.vstack((xgen_r, xgen_i))
    xgen_ = tf.dtypes.cast(xgen_, dtype=tf_floattype)

    if SNR is None:
      noise_var = 0
    else:
      noise_var = math.pow(10., -SNR / 10.)

    ygen_ = prob.code_symbol*tf.math.sign(tf.matmul(A_, xgen_) + tf.random_normal( (6*M, L),stddev=math.sqrt( noise_var),dtype=tf_floattype))
    ygen_ = tf.dtypes.cast(ygen_, dtype=tf_floattype)
    prob.xgen_ = xgen_
    prob.ygen_ = ygen_
    prob.noise_var = noise_var
    prob.pnz = pnz

    prob.xvall = (bernoulli_ * np.exp(1j*np.random.normal(0, 1, (N, L))))
    prob.xval_r = (10*np.real(prob.xvall)).astype(np.float32)
    prob.xval_i = (10*np.imag(prob.xvall)).astype(np.float32)
    prob.xval = np.vstack((prob.xval_r,prob.xval_i))
    prob.yval = prob.code_symbol*np.sign(np.matmul(A,prob.xval)+np.random.normal(0,math.sqrt(noise_var),(6*M,L)))

    return prob

