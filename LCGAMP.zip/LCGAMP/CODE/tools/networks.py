#!/usr/bin/python
from __future__ import division
from __future__ import print_function
import numpy as np
import numpy.linalg as la
import math

import tensorflow as tf
import tensorflow_probability as tfp
import tools.shrinkage as shrinkage

def build_LGAMP(prob, T, shrink, untied, tf_floattype=tf.float32):
    """
    Builds a LAMP network to infer x from prob.y_ = matmul(prob.A,x) + AWGN
    return a list of layer info (name,xhat_,newvars)
     name : description, e.g. 'LISTA T=1'
     xhat_ : that which approximates x_ at some point in the algorithm
     newvars : a tuple of layer-specific trainable variables
    """
    F, F_theta_init = shrinkage.get_shrinkage_function(shrink, prob)
    G, G_theta_init = shrinkage.get_shrinkage_function('bg', prob)

    F_theta_ = tf.constant(F_theta_init, dtype=tf_floattype, name='F_theta_0')
    G_theta_ = tf.Variable(G_theta_init, dtype=tf_floattype, name='G_theta_0')

    layers = []

    A = prob.A
    A_ = tf.dtypes.cast(prob.A_, dtype=tf_floattype)
    M, N = A.shape
    AT = A.T
    # This line causes numerical instability
    # AT = A.T / (1.01 * la.norm(A,2)**2)
    AT_ = tf.Variable(AT, dtype=tf_floattype, name='AT')
    A_A = np.multiply(A, A)
    A_A_ = tf.constant(A_A, dtype=tf_floattype, name='AA')
    A_AT_ = tf.transpose(A_A_)

    sigma_x2 = tf.constant(1, dtype=tf_floattype)
    sigmaw2 = tf.constant(prob.noise_var, dtype=tf_floattype)
    code_scale = prob.code_symbol

    xhat_ = 0 * tf.matmul(AT_, prob.y_)
    xvar_ = tf.constant(prob.pnz, dtype=tf_floattype) * sigma_x2 * (1 + xhat_)
    s_ = 0 * prob.y_

    for t in range(0, T):
        pvar_ = tf.matmul(A_A_, xvar_)
        p_ = tf.matmul(A_, xhat_) - pvar_ * s_

        (s_, svar_) = F(prob.y_, p_, pvar_, sigmaw2, M, F_theta_, code_scale)

        svar_rm = tf.reduce_mean(svar_, axis=0)
        svar_ = tf.matmul(1 + 0 * svar_, tf.matrix_diag(svar_rm))

        rvar_ = tf.math.reciprocal(tf.matmul(A_AT_, svar_))

        rvar_rm = tf.reduce_mean(rvar_, axis=0)
        rvar_ = tf.matmul(1 + 0 * rvar_, tf.matrix_diag(rvar_rm))

        r_ = xhat_ + tf.matmul(AT_, s_) * rvar_

        (xhat_, dxdr_) = G(r_, rvar_, G_theta_)
        xvar_ = rvar_ * dxdr_  # Rangan GAMP, eq 8b

        layers.append( ('LGAMP T={0}'.format(t+1),xhat_,xvar_,r_,rvar_,s_,svar_,p_,pvar_,(G_theta_, )) )
        # layers.append(('LGAMP T={0}'.format(t + 1), xhat_, (G_theta_,)))

    return layers


