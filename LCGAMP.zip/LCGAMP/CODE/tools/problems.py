#!/usr/bin/python
from __future__ import division
from __future__ import print_function
import numpy as np
import numpy.linalg as la
import math
import tensorflow as tf
import random
import itertools
class Generator(object):
    def __init__(self,A,**kwargs):
        self.A = A
        M,N = A.shape
        vars(self).update(kwargs)
        self.x_ = tf.placeholder( tf.float32,(N,None),name='x' )
        self.y_ = tf.placeholder( tf.float32,(M,None),name='y' )

class TFGenerator(Generator):
    def __init__(self,**kwargs):
        Generator.__init__(self,**kwargs)
    def __call__(self,sess):
        'generates y,x pair for training'
        return sess.run( ( self.ygen_,self.xgen_ ) )

class NumpyGenerator(Generator):
    def __init__(self,**kwargs):
        Generator.__init__(self,**kwargs)

    def __call__(self,sess):
        'generates y,x pair for training'
        return self.p.genYX(self.nbatches,self.nsubprocs)


def one_bit_CS_with_BG_prior(M=1024,N=360,L=1000, pnz=.025, kappa=None, SNR=40, tf_floattype = tf.float32):
    # This function returns an object called prob which contains:
    # the measurement matrix, both numpy array A and TensorFlow constant A_,
    # Tensors xgen, ygen_ which can be used in TensorFlow to generate new training data,
    # numpy arrays xval and yval which are used to evaluate the learned network
    # numpy arrays xinit and yinit, which I am not sure are used at all ???
    # and a scalar noise_va
    f_c = 1e9  # frequency of operation
    w_lambda = 3e8 / f_c  # wavelength
    d = 0.5 * w_lambda  # uniform spacing of half wavelength

    # B1 = 341
    # B2 = 343
    B1 = 101
    B2 = 119
    b1 = np.array(B1 * np.linspace(0, B2 - 1, B2))
    b2 = np.array(B2 * np.linspace(1, 2 * B1 - 1, 2 * B1 - 1))
    position_x_u = np.sort(np.append(b1, b2))*d

    # array_length = (M - 1) * d
    # position_x_u = np.linspace(-array_length / 2, array_length / 2, M)
    position_x_u = position_x_u.reshape(M, 1)  # uniform positions for ULA

    def generate_random_signals(lower_bound, upper_bound, size, scale=None):
        sample_space = (lower_bound + upper_bound) / 2
        if scale is None:
            scale = (upper_bound - lower_bound) / 2
        results = []
        while len(results) < size:
            samples = np.random.normal(loc=sample_space, scale=scale, size=size - len(results))
            results += [sample for sample in samples if lower_bound <= sample <= upper_bound]
        return np.array(results)


    az_theta_D = generate_random_signals(-90, 90, N)
    az_theta = az_theta_D * math.pi / 180  # DOA to estimate
    phi = np.array(2 * math.pi * np.sin(az_theta) / w_lambda)
    phi = phi.reshape(N, 1)
    A = np.exp(1j * np.dot(position_x_u,phi.T))
    AR = np.real(A)
    AI = np.imag(A)
    A = np.vstack((np.hstack((AR, -AI)), np.hstack((AI, AR))))
    A = np.vstack((A, A, A))
    A_ = tf.constant(A, name='A', dtype=tf_floattype)
    prob = TFGenerator(A=A, tf_floattype=tf_floattype, A_=A_,pnz=pnz,kappa=kappa,SNR=SNR)
    prob.name = '1bit CS, BG prior, Gaussian A'
    prob.pnz = pnz
    # prob.code_symbol = np.sqrt(prob.pnz*N/M)
    K = 3
    prob.code_symbol = np.sqrt(K / M)

    # bernoulli_ = ( np.random.uniform( 0, 1, (N, L) ) < pnz).astype(np.complex)
    bernoulli_1 = np.zeros((N, L))
    for i in range(0, L):
        random_list = list(range(1, N))
        index = random.sample(random_list, K)
        index = np.sort(np.array(index))
        bernoulli_1[index,i] = 1
    bernoulli_1 = (bernoulli_1).astype(np.complex)
    xgenn_ = bernoulli_1 * np.exp(1j*np.random.normal(0, 1, (N, L)))
    xgen_r = (10*np.real(xgenn_)).astype(np.float32)
    xgen_i = (10*np.imag(xgenn_)).astype(np.float32)
    xgen_1 = np.vstack((xgen_r, xgen_i))

    bernoulli_2 = np.zeros((N, L))
    for i in range(0, L ):
        random_list = list(range(1, N))
        index = random.sample(random_list, K)
        index = np.sort(np.array(index))
        bernoulli_2[index, i] = 1
    bernoulli_2 = (bernoulli_2).astype(np.complex)
    xgenn_ = bernoulli_2 * np.exp(1j * np.random.normal(0, 1, (N, L)))
    xgen_r = (10 * np.real(xgenn_)).astype(np.float32)
    xgen_i = (10 * np.imag(xgenn_)).astype(np.float32)
    xgen_2 = np.vstack((xgen_r, xgen_i))

    bernoulli_3 = np.zeros((N, L))
    for i in range(0, L ):
        random_list = list(range(1, N))
        index = random.sample(random_list, K)
        index = np.sort(np.array(index))
        bernoulli_3[index, i] = 1
    bernoulli_3 = (bernoulli_3).astype(np.complex)
    xgenn_ = bernoulli_3 * np.exp(1j * np.random.normal(0, 1, (N, L)))
    xgen_r = (10 * np.real(xgenn_)).astype(np.float32)
    xgen_i = (10 * np.imag(xgenn_)).astype(np.float32)
    xgen_3 = np.vstack((xgen_r, xgen_i))
    xgen_ = np.hstack((xgen_1, xgen_2, xgen_3))
    xgen_ = tf.dtypes.cast(xgen_, dtype=tf_floattype)


    if SNR is None:
      noise_var = 0
    else:
      noise_var = prob.code_symbol*math.pow(10., -SNR / 10.)

    ygen_ = prob.code_symbol*tf.math.sign(tf.matmul(A_, xgen_) + tf.random_normal( (6*M, 3*L),stddev=math.sqrt( noise_var),dtype=tf_floattype))
    ygen_ = tf.dtypes.cast(ygen_, dtype=tf_floattype)
    prob.xgen_ = xgen_
    prob.ygen_ = ygen_
    prob.noise_var = noise_var
    prob.pnz = pnz

    prob.xvall1 = (bernoulli_1 * np.exp(1j*np.random.normal(0, 1, (N, L))))
    prob.xval_r = (10*np.real(prob.xvall1)).astype(np.float32)
    prob.xval_i = (10*np.imag(prob.xvall1)).astype(np.float32)
    prob.xval1 = np.vstack((prob.xval_r,prob.xval_i))
    prob.xvall2 = (bernoulli_2 * np.exp(1j * np.random.normal(0, 1, (N, L))))
    prob.xval_r = (10 * np.real(prob.xvall2)).astype(np.float32)
    prob.xval_i = (10 * np.imag(prob.xvall2)).astype(np.float32)
    prob.xval2 = np.vstack((prob.xval_r, prob.xval_i))
    prob.xvall3 = (bernoulli_3 * np.exp(1j * np.random.normal(0, 1, (N, L))))
    prob.xval_r = (10 * np.real(prob.xvall3)).astype(np.float32)
    prob.xval_i = (10 * np.imag(prob.xvall3)).astype(np.float32)
    prob.xval3 = np.vstack((prob.xval_r, prob.xval_i))
    prob.xval = np.hstack((prob.xval1,prob.xval2,prob.xval3))
    prob.yval = prob.code_symbol*np.sign(np.matmul(A,prob.xval)+np.random.normal(0,math.sqrt(noise_var),(6*M,3*L)))

    return prob


