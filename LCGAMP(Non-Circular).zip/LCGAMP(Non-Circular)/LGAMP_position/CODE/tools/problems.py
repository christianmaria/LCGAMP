#!/usr/bin/python
from __future__ import division
from __future__ import print_function
import numpy as np
import numpy.linalg as la
import math
import tensorflow as tf

class Generator(object):
    def __init__(self,A,**kwargs):
        self.A = A
        M,N = A.shape
        vars(self).update(kwargs)
        self.x_ = tf.placeholder( tf.float32,(N,None),name='x' )
        # self.h_ = tf.placeholder( tf.float32,(N,None),name='h' )
        self.y_ = tf.placeholder( tf.float32,(M,None),name='y' )

class TFGenerator(Generator):
    def __init__(self,**kwargs):
        Generator.__init__(self,**kwargs)
    def __call__(self,sess):
        # 'generates y,x pair for training'
        return sess.run( ( self.ygen_,self.xgen_ ) )
        # 'generates y,h pair for training'
        # return sess.run((self.ygen_, self.hgen_))
class NumpyGenerator(Generator):
    def __init__(self,**kwargs):
        Generator.__init__(self,**kwargs)
    def __call__(self,sess):
        'generates y,x pair for training'
        return self.p.genYX(self.nbatches,self.nsubprocs)


def one_bit_CS_with_BG_prior(M=1024,N=360,L=1000, pnz=.025, kappa=None, SNR=40, tf_floattype = tf.float32):
    # This function returns an object called prob which contains:
    # the measurement matrix, both numpy array A and TensorFlow constant A_,
    # Tensors xgen, ygen_ which can be used in TensorFlow to generate new training data,
    # numpy arrays xval and yval which are used to evaluate the learned network
    # numpy arrays xinit and yinit, which I am not sure are used at all ???
    # and a scalar noise_va
    f_c = 1e9  # frequency of operation
    w_lambda = 3e8 / f_c  # wavelength
    d = 0.5 * w_lambda  # uniform spacing of half wavelength
    # array_length = (M - 1) * d
    # B1 = 341
    # B2 = 343
    B1 = 101
    B2 = 119
    b1 = np.array(B1 * np.linspace(0, B2 - 1, B2))*d
    b2 = np.array(B2 * np.linspace(1, 2 * B1 - 1, 2 * B1 - 1))*d
    position_x_u = np.sort(np.append(b1, b2))
    # position_x_u = np.linspace(-array_length / 2, array_length / 2, M)
    position_x_u = position_x_u.reshape(M, 1)  # uniform positions for ULA

    def generate_random_signals(lower_bound, upper_bound, size, scale=None):
        sample_space = (lower_bound + upper_bound) / 2
        if scale is None:
            scale = (upper_bound - lower_bound) / 2
        results = []
        while len(results) < size:
            samples = np.random.normal(loc=sample_space, scale=scale, size=size - len(results))
            results += [sample for sample in samples if lower_bound <= sample <= upper_bound]
        return np.array(results)

        # az_theta_D = np.array([5,20,-15])

    az_theta_D = generate_random_signals(-90, 90, N)
    # az_theta_D = np.random.uniform(-90,90,(N,L)).astype(np.float32)
    az_theta = az_theta_D * math.pi / 180  # DOA to estimate
    phi = np.array(2 * math.pi * np.sin(az_theta) / w_lambda)
    phi = phi.reshape(N, 1)
    A = np.exp(1j * np.dot(position_x_u,phi.T))
    # A = np.random.normal(size=(M, N), scale=1.0 / math.sqrt(M)).astype(np.float32)
    AR = np.real(A)
    AI = np.imag(A)
    zero = np.zeros((M,N))
    A = np.vstack((np.hstack((AR, -AI, zero, zero,zero,zero,zero,zero,zero,zero,zero,zero)), \
                   np.hstack((AI, AR, zero, zero,zero,zero,zero,zero,zero,zero,zero,zero)),\
                   np.hstack((zero, zero, AR, AI,zero, zero,zero,zero,zero,zero,zero,zero)), \
                   np.hstack((zero, zero, -AI, AR,zero, zero,zero,zero,zero,zero,zero,zero)), \
                   np.hstack((zero, zero, zero, zero,AR, -AI, zero,zero,zero,zero,zero,zero)), \
                   np.hstack((zero, zero, zero, zero,AI, AR, zero,zero,zero,zero,zero,zero)), \
                   np.hstack((zero, zero, zero, zero, zero, zero,AR, AI, zero, zero, zero, zero)), \
                   np.hstack((zero, zero, zero, zero, zero, zero,-AI, AR, zero, zero, zero, zero)), \
                   np.hstack((zero, zero, zero, zero, zero, zero,zero, zero, AR, -AI, zero, zero)), \
                   np.hstack((zero, zero, zero, zero, zero, zero, zero, zero,AI, AR, zero, zero)), \
                   np.hstack((zero, zero, zero, zero, zero, zero, zero, zero,zero, zero, AR, AI)), \
                   np.hstack((zero, zero, zero, zero, zero, zero, zero, zero, zero, zero,-AI, AR))))
    A_ = tf.constant(A, name='A', dtype=tf_floattype)
    prob = TFGenerator(A=A, tf_floattype=tf_floattype, A_=A_,pnz=pnz,kappa=kappa,SNR=SNR)
    prob.name = '1bit CS, BG prior, Gaussian A'
    prob.pnz = pnz
    prob.code_symbol = np.sqrt(prob.pnz*N/M)

    bernoulli_1 = ( np.random.uniform( 0, 1, (N, L) ) < pnz).astype(np.complex)
    # xgen_ = bernoulli_ * tf.random_normal( (N,L) )
    xgenn_1 = bernoulli_1 * np.exp(1j*np.random.normal(0, 1, (N, L)))
    xgen_r1 = (10*np.real(xgenn_1)).astype(np.float32)
    xgen_i1 = (10*np.imag(xgenn_1)).astype(np.float32)
    bernoulli_2 = (np.random.uniform(0, 1, (N, L)) < pnz).astype(np.complex)
    # xgen_ = bernoulli_ * tf.random_normal( (N,L) )
    xgenn_2 = bernoulli_2 * np.exp(1j * np.random.normal(0, 1, (N, L)))
    xgen_r2 = (10 * np.real(xgenn_2)).astype(np.float32)
    xgen_i2 = (10 * np.imag(xgenn_2)).astype(np.float32)
    bernoulli_3 = (np.random.uniform(0, 1, (N, L)) < pnz).astype(np.complex)
    # xgen_ = bernoulli_ * tf.random_normal( (N,L) )
    xgenn_3 = bernoulli_1 * np.exp(1j * np.random.normal(0, 1, (N, L)))
    xgen_r3 = (10 * np.real(xgenn_3)).astype(np.float32)
    xgen_i3 = (10 * np.imag(xgenn_3)).astype(np.float32)
    xgen_ = np.vstack((xgen_r1, xgen_i1, xgen_r1, -xgen_i1, xgen_r2, xgen_i2, xgen_r2, -xgen_i2, xgen_r3, xgen_i3, xgen_r3, -xgen_i3))
    xgen_ = tf.dtypes.cast(xgen_, dtype=tf_floattype)
    # hgen_r = bernoulli_
    # hgen_i = bernoulli_
    # hgen_ = np.vstack((hgen_r, hgen_i))
    # hgen_ = tf.dtypes.cast(hgen_, dtype=tf_floattype)


    if SNR is None:
      noise_var = 0
    else:
      # This definition is with correspondence to the MATLAB code
      # Here the SNR is related to P(y)/P(w)
      # noise_var = math.pow(10., -SNR / 10.)*prob.code_symbol**2
      # where as in this definition SNR is related to P(x)/P(w)
      # noise_var = pnz * N / M * math.pow(10., -SNR / 10.)
      noise_var = math.pow(10., -SNR / 10.)

    ygen_ = prob.code_symbol*tf.math.sign(tf.matmul(A_, xgen_) + tf.random_normal( (12*M, L),stddev=math.sqrt( noise_var),dtype=tf_floattype))
    ygen_ = tf.dtypes.cast(ygen_, dtype=tf_floattype)
    prob.xgen_ = xgen_
    # prob.hgen_ = hgen_
    prob.ygen_ = ygen_
    prob.noise_var = noise_var
    prob.pnz = pnz

    # prob.xval = ((np.random.uniform( 0,1,(N,L))<pnz) * np.random.normal(0,1,(N,L))).astype(np.float32)
    bernoulli_1 = ( np.random.uniform( 0, 1, (N, L)) < pnz).astype(np.complex)
    prob.xvall1 = (bernoulli_1 * np.exp(1j*np.random.normal(0, 1, (N, L))))
    prob.xval_r1 = (10*np.real(prob.xvall1)).astype(np.float32)
    prob.xval_i1 = (10*np.imag(prob.xvall1)).astype(np.float32)
    bernoulli_2 = (np.random.uniform(0, 1, (N, L)) < pnz).astype(np.complex)
    prob.xvall2 = (bernoulli_2 * np.exp(1j * np.random.normal(0, 1, (N, L))))
    prob.xval_r2 = (10 * np.real(prob.xvall2)).astype(np.float32)
    prob.xval_i2 = (10 * np.imag(prob.xvall2)).astype(np.float32)
    bernoulli_3 = (np.random.uniform(0, 1, (N, L)) < pnz).astype(np.complex)
    prob.xvall3 = (bernoulli_3 * np.exp(1j * np.random.normal(0, 1, (N, L))))
    prob.xval_r3 = (10 * np.real(prob.xvall3)).astype(np.float32)
    prob.xval_i3 = (10 * np.imag(prob.xvall3)).astype(np.float32)
    prob.xval = np.vstack((prob.xval_r1,prob.xval_i1,prob.xval_r1,-prob.xval_i1,\
                           prob.xval_r2,prob.xval_i2,prob.xval_r2,-prob.xval_i2,\
                           prob.xval_r3,prob.xval_i3,prob.xval_r3,-prob.xval_i3))
    prob.yval = prob.code_symbol*np.sign(np.matmul(A,prob.xval)+np.random.normal(0,math.sqrt(noise_var),(12*M,L)))
    # prob.hval_r = bernoulli_1
    # prob.hval_i = bernoulli_1
    # prob.hval = np.vstack((prob.hval_r, prob.hval_i))
    # prob.noise = np.random.normal(0,math.sqrt( noise_var ),(2*M,L))
    # prob.yval = prob.y_starval+prob.noise

    prob.y_cleanval = np.matmul(A, prob.xval)
    prob.noise = np.random.normal(0, math.sqrt(noise_var), (N, L))

    # Uncomment for checking SNR
    y_clean_norm2 = np.mean(la.norm(prob.y_cleanval, axis=0)**2)
    noise_norm2 = np.mean(la.norm(prob.noise, axis=0)**2)
    SNR_empirical = y_clean_norm2/noise_norm2
    SNR_dB_empirical = 10*np.log10(SNR_empirical)
    print('SNR_dB_empirical=', SNR_dB_empirical)

    # # prob.xinit = ((np.random.uniform( 0,1,(N,L))<pnz) * np.random.normal(0,1,(N,L))).astype(np.float32)
    # bernoulli_2 = ( np.random.uniform( 0, 1, (N, L)) < pnz).astype(np.complex)
    # prob.xinitt = (bernoulli_2 * np.exp(1j*np.random.normal(0, 1, (N, L))))
    # prob.xinit_r = (10*np.real(prob.xinitt)).astype(np.float32)
    # prob.xinit_i = (10*np.imag(prob.xinitt)).astype(np.float32)
    # prob.xinit = np.vstack((prob.xinit_r, prob.xinit_i))
    # prob.yinit = np.sign(np.matmul(A,prob.xinit)+np.random.normal(0,math.sqrt(noise_var),(2*M,L)))




    # y_star_test = prob.y_starval

    # y_starval_norm2 = la.norm(prob.y_starval)**2
    # noise_norm2 = la.norm(prob.noise)**2
    #
    # # print('y_star_test size is', y_star_test.size)
    # # print('y_starval norm2 is', y_starval_norm2)
    # # print('prob.noise var=',prob.noise_var)
    # # print('noise norm2 is', noise_norm2)
    #
    # SNR = 10*np.log10(y_starval_norm2 / noise_norm2)
    # print('SNR=',SNR)

    return prob


