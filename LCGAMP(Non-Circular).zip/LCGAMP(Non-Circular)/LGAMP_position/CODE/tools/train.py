#!/usr/bin/python
from __future__ import division
from __future__ import print_function
import numpy as np
import numpy.linalg as la
import sys
from libs import detect_peaks
# from detecta import detect_peaks
# import scipy.signal
from libs.findpeaks import findpeaks
import tensorflow as tf
import time
import matplotlib.pyplot as plt
import random

def maxk(arraylist, k):
    maxlist = []
    maxlist_id = list(range(0, k))
    m = [maxlist, maxlist_id]
    for i in maxlist_id:
        maxlist.append(arraylist[i])
    for i in range(k, len(arraylist)):  # 对目标数组之后的数字
        if arraylist[i] > min(maxlist):
            mm = maxlist.index(min(maxlist))
            del m[0][mm]
            del m[1][mm]
            m[0].append(arraylist[i])
            m[1].append(i)
    return maxlist_id

def save_trainable_vars(sess,filename,**kwargs):
    """save a .npz archive in `filename`  with
    the current value of each variable in tf.trainable_variables()
    plus any keyword numpy arrays.
    """
    save={}
    for v in tf.trainable_variables():
        save[str(v.name)] = sess.run(v)
    save.update(kwargs)
    np.savez(filename,**save)

def load_trainable_vars(sess,filename):
    """load a .npz archive and assign the value of each loaded
    ndarray to the trainable variable whose name matches the
    archive key.  Any elements in the archive that do not have
    a corresponding trainable variable will be returned in a dict.
    """
    other={}
    try:
        tv=dict([ (str(v.name),v) for v in tf.trainable_variables() ])
        for k,d in np.load(filename).items():
            if k in tv:
                print('restoring ' + k + ' is:' + str(d))
                sess.run(tf.assign( tv[k], d) )
            else:
                other[k] = d
    except IOError:
        pass
    return other

def get_train_variables(sess):
    """save a .npz archive in `filename`  with
        the current value of each variable in tf.trainable_variables()
        plus any keyword numpy arrays.
        """
    save={}
    for v in tf.trainable_variables():
        save[str(v.name)] = sess.run(v)

    return save


def setup_LGAMPtraining(layer_info,prob, trinit=1e-3,refinements=(.5,.1,.01),final_refine=None ):
    """ Given a list of layer info (name,xhat_,newvars),
    create an output list of training operations (name,xhat_,loss_,nmse_,trainop_ ).
    Each layer_info element will be split into one or more output training operations
    based on the presence of newvars and len(refinements)
    """
    global sigma2_empirical_, se_, rvar_, xhat_, loss_, name, sigma2_
    losses_=[]
    nmse_=[]
    trainers_=[]
    assert np.array(refinements).min()>0,'all refinements must be in (0,1]'
    assert np.array(refinements).max()<=1,'all refinements must be in (0,1]'

    maskX_ = getattr(prob,'maskX_',1)
    if maskX_ != 1:
        print('masking out inconsequential parts of signal x for nmse reporting')

    nmse_denom_ = tf.nn.l2_loss(prob.x_ *maskX_)
    # nmse_denom_ = tf.nn.l2_loss(prob.h_ * maskX_)
    tr_ = tf.Variable(trinit,name='tr',trainable=False)
    training_stages=[]

    for name, xhat_, xvar_, r_, rvar_, sigma2_empirical_,se_, p_, pvar_, var_list in layer_info:
    # for name,xhat_,var_list in layer_info:

        loss_  = tf.nn.l2_loss( xhat_/tf.norm(xhat_, axis=0) - prob.x_/tf.norm(prob.x_, axis=0))
        nmse_  = tf.reduce_mean(tf.norm(xhat_/tf.norm(xhat_, axis=0) - prob.x_/tf.norm(prob.x_, axis=0), axis=0)**2)

        sigma2_empirical_ = tf.reduce_mean((r_ - prob.x_) ** 2)
        se_ = 2 * tf.nn.l2_loss(xhat_ - prob.x_)  # to get MSE, divide by / (L * N)


        if var_list is not None:
            train_ = tf.train.AdamOptimizer(tr_).minimize(loss_, var_list=var_list)
            training_stages.append((name, xhat_, rvar_, loss_, nmse_, sigma2_empirical_, se_, train_, var_list))
        for fm in refinements:
            train2_ = tf.train.AdamOptimizer(tr_ *fm).minimize(loss_)
            training_stages.append( (name+' trainrate=' + str(fm) ,xhat_,rvar_,loss_,nmse_,sigma2_empirical_,se_,train2_,()) )
    if final_refine:
        train2_ = tf.train.AdamOptimizer(tr_ * final_refine).minimize(loss_)
        training_stages.append(
            (name + ' final refine ' + final_refine, xhat_, rvar_, loss_, nmse_, sigma2_empirical_, se_, train2_, ()))
    return training_stages

def do_training(training_stages,prob,savefile,ivl=10,maxit=1000000,better_wait=5000):
    """
    ivl:how often should we compute the nmse of the validation set?
    maxit: max number of training iterations
    better_wait:wait this many iterations for an nmse that is better than the prevoius best of the current training session
    """
    sess = tf.Session()
    sess.run(tf.global_variables_initializer())

    print('norms xval:{xval:.7f} yval:{yval:.7f}'.format(xval=la.norm(prob.xval), yval=la.norm(prob.yval) ) )

    state = load_trainable_vars(sess,savefile) # must load AFTER the initializer

    # must use this same Session to perform all training
    # if we start a new Session, things would replay and we'd be training with our validation set (no no)

    done=state.get('done',[])
    log=str(state.get('log',''))

    for name,xhat_,rvar_,loss_,nmse_,sigma2_empirical_,se_,train_,var_list in training_stages:
        start = time.time()
        if name in done:
            print('Already did ' + name + '. Skipping.')
            continue
        if len(var_list):
            describe_var_list = 'extending ' + ','.join([v.name for v in var_list])
        else:
            describe_var_list = 'fine tuning all ' + ','.join([v.name for v in tf.trainable_variables() ])

        print(name + ' ' + describe_var_list)
        nmse_history=[]
        for i in range(maxit+1):
            if i%ivl == 0:
                nmse = sess.run(nmse_,feed_dict={prob.y_:prob.yval,prob.x_:prob.xval})
                if np.isnan(nmse):
                    continue
                nmse_history = np.append(nmse_history,nmse)
                nmse_dB = 10*np.log10(nmse)
                nmsebest_dB = 10*np.log10(nmse_history.min())
                sys.stdout.write('\ri={i:<6d} nmse={nmse:.6f} dB (best={best:.6f})'.format(i=i,nmse=nmse_dB,best=nmsebest_dB))
                sys.stdout.flush()
                if i%(100*ivl) == 0:
                    print('')
                    age_of_best = len(nmse_history) - nmse_history.argmin()-1 # how long ago was the best nmse?
                    if age_of_best*ivl > better_wait:
                        break # if it has not improved on the best answer for quite some time, then move along
            y,x = prob(sess)
            sess.run(train_,feed_dict={prob.y_:y,prob.x_:x} )
        done = np.append(done,name)

        end = time.time()
        time_log = 'Took me {totaltime:.3f} minutes, or {time_per_interation:.1f} ms per iteration'.format(totaltime = (end-start)/60, time_per_interation = (end-start)*1000/i)
        print(time_log)
        log =  log+'\n{name} nmse={nmse:.6f} dB in {i} iterations'.format(name=name,nmse=nmse_dB,i=i)

        state['done'] = done
        state['log'] = log
        save_trainable_vars(sess,savefile,**state)
    return sess




def evaluate_LGAMP_nmse(sess, training_stages, prob, pnz=.008, SNR=40):
    global x_hat, name, nmse
    import math
    SNR = []
    MSE = np.zeros((1, len(SNR)))
    error = np.zeros((1, len(SNR)))
    totaltime = np.zeros((1, len(SNR)))

    K=3
    for ii in range(0, len(SNR)):
        A = prob.A
        M, N = A.shape
        Monte = 500
        for monte in range(0, Monte):
            scale = prob.code_symbol
            noise_var = math.pow(10., -SNR[ii] / 10.)
            data_set_size = 1
            bernoulli_1 = np.zeros((181, data_set_size))
            index = []
            # for i in range(0, data_set_size):
            #     random_list = list(range(1, 181))
            #     index = random.sample(random_list, K)
            #     index = np.sort(np.array(index))
            #     bernoulli_1[index, i] = 1
            bernoulli_1[index] = 1
            bernoulli_1 = (bernoulli_1).astype(np.complex)
            xgenn_1 = bernoulli_1 * np.exp(1j * np.random.normal(0, 1, (181, data_set_size)))
            xgen_r1 = (10 * np.real(xgenn_1)).astype(np.float32)
            xgen_i1 = (10 * np.imag(xgenn_1)).astype(np.float32)

            bernoulli_2 = np.zeros((181, data_set_size))
            index = []
            # for i in range(0, data_set_size):
            #     random_list = list(range(1, 181))
            #     index = random.sample(random_list, K)
            #     index = np.sort(np.array(index))
            #     bernoulli_2[index, i] = 1
            bernoulli_2[index] = 1
            bernoulli_2 = (bernoulli_2).astype(np.complex)
            xgenn_2 = bernoulli_2 * np.exp(1j * np.random.normal(0, 1, (181, data_set_size)))
            xgen_r2 = (10 * np.real(xgenn_2)).astype(np.float32)
            xgen_i2 = (10 * np.imag(xgenn_2)).astype(np.float32)

            bernoulli_3 = np.zeros((181, data_set_size))
            index = []
            # for i in range(0, data_set_size):
            #     random_list = list(range(1, 181))
            #     index = random.sample(random_list, K)
            #     index = np.sort(np.array(index))
            #     bernoulli_3[index, i] = 1
            bernoulli_3[index] = 1
            bernoulli_3 = (bernoulli_3).astype(np.complex)
            xgenn_3 = bernoulli_3 * np.exp(1j * np.random.normal(0, 1, (181, data_set_size)))
            xgen_r3 = (10 * np.real(xgenn_3)).astype(np.float32)
            xgen_i3 = (10 * np.imag(xgenn_3)).astype(np.float32)

            xtest = np.vstack((xgen_r1, xgen_i1, xgen_r1, -xgen_i1,\
                               xgen_r2, xgen_i2, xgen_r2, -xgen_i2,\
                               xgen_r3, xgen_i3, xgen_r3, -xgen_i3))

            ytest = scale*np.sign(np.matmul(A, xtest) + np.random.normal(0, math.sqrt(noise_var), (M, data_set_size)))
            x_true = xtest
            start = time.time()
            for name, xhat_, rvar_, loss_, nmse_, sigma2_empirical_, se_, train_, var_list in training_stages:
                if " trainrate=" not in name:
                    x_hat = sess.run(xhat_, feed_dict={prob.y_: ytest, prob.x_: xtest})
                    nmse = sess.run(nmse_, feed_dict={prob.y_: ytest, prob.x_: xtest})
                    if np.isnan(nmse):
                        continue
                    nmse_dB = 10 * np.log10(nmse)
                    print('{name} NMSE= {nmse:.6f} \tdB'.format(name=name, nmse=nmse_dB))
            end = time.time()
            totaltime[:,ii] = totaltime[:,ii] + (end - start)
            if np.isnan(nmse):
                continue

            x_true1 = x_true[0:181,0]**2 + x_true[181:362,0]**2 + x_true[362:543,0]**2 + x_true[543:724,0]**2
            x_hat1 = x_hat[0:181,0]**2 + x_hat[181:362,0]**2 + x_hat[362:543,0]**2 + x_hat[543:724,0]**2
            x_true2 = x_true[724:905,0]**2 + x_true[905:1086,0]**2 + x_true[1086:1267,0]**2 + x_true[1267:1448,0]**2
            x_hat2 = x_hat[724:905,0]**2 + x_hat[905:1086,0]**2 + x_hat[1086:1267,0]**2 + x_hat[1267:1448,0]**2
            x_true3 = x_true[1448:1629,0]**2 + x_true[1629:1810,0]**2 + x_true[1810:1991,0]**2 + x_true[1991:2172,0]**2
            x_hat3 = x_hat[1448:1629,0]**2 + x_hat[1629:1810,0]**2 + x_hat[1810:1991,0]**2 + x_hat[1991:2172,0]**2

            index11 = maxk(x_true1, K)
            index11 = np.array(list(index11))
            index12 = maxk(x_hat1, K)
            index12 = np.array(list(index12))

            True_DOA1 = -90 + (index11) * 180 / 180
            Estimated_DOA1 = -90 + (index12) * 180 / 180
            index21 = maxk(x_true2, K)
            index21 = np.array(list(index21))
            index22 = maxk(x_hat2, K)
            index22 = np.array(list(index22))

            True_DOA2 = -90 + (index21) * 180 / 180
            Estimated_DOA2 = -90 + (index22) * 180 / 180
            index31 = maxk(x_true3, K)
            index31 = np.array(list(index31))
            index32 = maxk(x_hat3, K)
            index32 = np.array(list(index32))
            
            True_DOA3 = -90 + (index31) * 180 / 180
            Estimated_DOA3 = -90 + (index32) * 180 / 180
            errorr = (np.sum((True_DOA1 - Estimated_DOA1) ** 2 + (True_DOA2 - Estimated_DOA2) ** 2 + (True_DOA3- Estimated_DOA3) ** 2) / K) / 3
            print(errorr)
            error[:, ii] = errorr
            MSE[:, ii] = MSE[:, ii] + error[:, ii]

    RMSE = np.sqrt(MSE/Monte)
